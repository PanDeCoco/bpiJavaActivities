package seatwork1;

public class book {
    String title = "title of the book";
    int page = 2;


    void booktitle() {
        System.out.print("The title of the book " + title);
    }
    void pagenum() {
        System.out.print("Number of pages " + page);
    }
}